# AI Cyber Safety Coach

A simple web app where a user pastes an email, text message, or link and gets:

- **Risk label**: Safe / Suspicious / High Risk
- **Top 3 reasons** in plain language
- **Recommended next steps**
- **Confidence score**

Built for a hackathon MVP. Works with or without an OpenAI API key.

---

## Setup (GitHub Codespaces or local)

```bash
# 1. Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your API key (optional — app works without it)
#    Create a .env file:
echo "OPENAI_API_KEY=your-key-here" > .env
echo "FLASK_SECRET_KEY=some-random-string" >> .env

# 4. Run the app
python app.py
```

App runs at: **http://localhost:5000**

---

## GitHub Codespaces

Add secrets in: **Settings → Secrets and variables → Codespaces**

| Secret | Value |
|--------|-------|
| `OPENAI_API_KEY` | Your OpenAI key |
| `FLASK_SECRET_KEY` | Any random string |

Then run `python app.py`. Codespaces will auto-forward port 5000 as a public URL.

---

## Pages

| Route | Description |
|-------|-------------|
| `/` | Homepage — paste input, analyze |
| `/result` | Result — risk label, reasons, next steps |
| `/metrics` | Log of all analyses run |

---

## How it works

1. **Layer 1 — Rules**: Checks for urgency words, credential requests, scam language, threats, shortened links, and lookalike domains.
2. **Layer 2 — AI**: If `OPENAI_API_KEY` is set, sends input + detected flags to GPT-3.5-turbo for richer plain-language analysis.

Fallback to rules-only if no API key is present.

---

## File structure

```
ai-cyber-safety-coach/
├── app.py
├── requirements.txt
├── .gitignore
├── README.md
├── templates/
│   ├── index.html
│   ├── result.html
│   └── metrics.html
└── static/
    └── style.css
```

---

## Test scenarios

| Input type | Expected label |
|-----------|---------------|
| Fake bank suspension warning | High Risk |
| Fake professor gift card request | Suspicious |
| Normal library reminder | Safe |
| Password reset phishing email | High Risk |
| Shortened URL in message | Suspicious |

---

*For educational demo purposes only. Do not paste real private data.*
