import os
import json
import sqlite3
import re
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-key-change-in-prod")

DB_PATH = "cybercoach.sqlite3"

# ── Database setup ────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analysis_logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at  TEXT    NOT NULL,
                user_input  TEXT    NOT NULL,
                risk_label  TEXT    NOT NULL,
                reasons_json TEXT   NOT NULL,
                actions_json TEXT   NOT NULL,
                confidence  REAL    NOT NULL,
                used_ai     INTEGER NOT NULL DEFAULT 0,
                rating      INTEGER
            )
        """)
        conn.commit()

# ── Rule-based detection ──────────────────────────────────────────────────────

URGENCY_WORDS = [
    "urgent", "immediately", "now", "final notice", "suspended", "act now",
    "expires today", "last chance", "limited time", "right away", "asap",
    "warning", "alert", "critical", "deadline"
]

CREDENTIAL_WORDS = [
    "password", "login", "verify account", "ssn", "social security",
    "bank info", "credit card", "account number", "billing", "pin",
    "security code", "confirm your identity", "sign in", "log in"
]

SCAM_WORDS = [
    "gift card", "prize", "winner", "you won", "refund", "lottery",
    "claim your reward", "free money", "unclaimed", "inheritance",
    "investment opportunity", "guaranteed return"
]

THREAT_WORDS = [
    "account suspended", "legal action", "payment overdue", "arrest",
    "lawsuit", "irs", "police", "federal", "prosecuted", "court order"
]

SHORT_LINK_DOMAINS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "rb.gy", "short.link"]

SAFE_DOMAINS = [
    "google.com", "microsoft.com", "apple.com", "amazon.com",
    "github.com", "linkedin.com", "edu", ".gov"
]

def rules_analysis(text):
    text_lower = text.lower()
    flags = []

    urgency_hits = [w for w in URGENCY_WORDS if w in text_lower]
    if urgency_hits:
        flags.append(("urgency", f"Urgency language detected: {', '.join(urgency_hits[:2])}"))

    cred_hits = [w for w in CREDENTIAL_WORDS if w in text_lower]
    if cred_hits:
        flags.append(("credential", f"Sensitive information requested: {', '.join(cred_hits[:2])}"))

    scam_hits = [w for w in SCAM_WORDS if w in text_lower]
    if scam_hits:
        flags.append(("scam", f"Reward/scam language detected: {', '.join(scam_hits[:2])}"))

    threat_hits = [w for w in THREAT_WORDS if w in text_lower]
    if threat_hits:
        flags.append(("threat", f"Threat language detected: {', '.join(threat_hits[:2])}"))

    # Check for shortened/suspicious links
    for domain in SHORT_LINK_DOMAINS:
        if domain in text_lower:
            flags.append(("short_link", f"Shortened link detected ({domain}) — destination is hidden"))
            break

    # Check for suspicious URL patterns
    url_pattern = re.findall(r'https?://[^\s]+', text, re.IGNORECASE)
    for url in url_pattern:
        # Lookalike domains (e.g. paypa1, amaz0n)
        if re.search(r'[a-z]+[0-9]+[a-z]+\.(com|net|org|xyz|ru|info)', url, re.IGNORECASE):
            flags.append(("fake_domain", "Lookalike/spoofed domain detected in link"))
        # Suspicious TLDs
        if re.search(r'\.(xyz|ru|tk|ml|ga|cf|gq|pw|top|click|download)$', url, re.IGNORECASE):
            flags.append(("suspicious_tld", "Suspicious domain extension in link"))

    # Determine risk level
    flag_types = [f[0] for f in flags]
    has_credential = "credential" in flag_types
    has_urgency    = "urgency" in flag_types
    has_threat     = "threat" in flag_types
    has_bad_link   = any(t in flag_types for t in ["short_link", "fake_domain", "suspicious_tld"])

    if (has_credential and has_urgency) or (has_threat and has_urgency) or (has_credential and has_bad_link):
        risk_label = "High Risk"
        confidence = min(0.70 + 0.05 * len(flags), 0.95)
    elif len(flags) >= 2:
        risk_label = "Suspicious"
        confidence = min(0.50 + 0.07 * len(flags), 0.85)
    elif len(flags) == 1:
        risk_label = "Suspicious"
        confidence = 0.55
    else:
        risk_label = "Safe"
        confidence = 0.80

    return risk_label, flags, round(confidence, 2)

def build_fallback_result(text, risk_label, flags):
    reasons_map = {
        "urgency":        "This message uses urgent language to pressure you into acting quickly without thinking",
        "credential":     "The message asks for sensitive personal or login information — legitimate services rarely do this",
        "scam":           "Reward or prize language is a common tactic used in phishing and scam messages",
        "threat":         "The message uses threats or legal warnings to intimidate you into complying",
        "short_link":     "A shortened link hides the real destination — you cannot verify where it leads",
        "fake_domain":    "The link contains a domain that mimics a well-known brand but is not the real site",
        "suspicious_tld": "The link uses an unusual domain extension commonly associated with scam sites",
    }

    top_reasons = [reasons_map[f[0]] for f in flags[:3]]
    if not top_reasons:
        top_reasons = [
            "No obvious red flags were detected in the text",
            "The message appears to follow normal communication patterns",
            "No suspicious links or credential requests were found"
        ]

    if risk_label == "High Risk":
        next_steps = [
            "Do not click any links in this message",
            "Do not provide any personal information or passwords",
            "Report this message as phishing to your email provider",
            "If you already clicked, change your passwords immediately",
            "Contact the real organization through their official website or phone number"
        ]
    elif risk_label == "Suspicious":
        next_steps = [
            "Do not click any links until you verify the sender",
            "Contact the sender directly using a known phone number or official website",
            "Check whether the sender's email domain matches the real organization",
            "When in doubt, delete the message and report it"
        ]
    else:
        next_steps = [
            "This message appears safe to read",
            "Always double-check links before clicking, even from trusted sources",
            "If anything feels off, verify through the official website directly"
        ]

    return {
        "risk_label": risk_label,
        "top_reasons": top_reasons,
        "next_steps": next_steps,
        "confidence": 0.0,  # overridden by caller
        "used_ai": False
    }

# ── OpenAI analysis ───────────────────────────────────────────────────────────

def ai_analysis(text, rule_flags):
    try:
        from openai import OpenAI
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return None

        client = OpenAI(api_key=api_key)

        flag_summary = ""
        if rule_flags:
            flag_summary = "\n\nRule-based flags already detected:\n" + "\n".join(f"- {f[1]}" for f in rule_flags)

        system_prompt = """You are an AI Cyber Safety Coach for non-technical users.

Your job is to analyze a pasted email, text message, or link and return:
1. risk_label: exactly one of "Safe", "Suspicious", or "High Risk"
2. top_reasons: exactly 3 short bullet reasons in plain language (no jargon)
3. next_steps: 3 to 5 safe recommended actions in plain language
4. confidence: a number from 0.0 to 1.0

Rules:
- Use simple language. Imagine explaining to someone's grandparent.
- Be cautious and safety-focused.
- Do not provide any information that could help scammers.
- If uncertain, recommend safe verification steps.
- Return ONLY valid JSON. No markdown, no code fences, no extra text.

JSON format:
{
  "risk_label": "High Risk",
  "top_reasons": ["reason 1", "reason 2", "reason 3"],
  "next_steps": ["step 1", "step 2", "step 3"],
  "confidence": 0.92
}"""

        user_message = f"Analyze this message for safety:\n\n{text}{flag_summary}"

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_message}
            ],
            temperature=0.2,
            max_tokens=500
        )

        raw = response.choices[0].message.content.strip()
        # Strip markdown fences if model ignores instructions
        raw = re.sub(r"```json|```", "", raw).strip()
        result = json.loads(raw)

        # Validate required fields
        assert "risk_label" in result
        assert "top_reasons" in result
        assert "next_steps" in result
        result["used_ai"] = True
        result["confidence"] = float(result.get("confidence", 0.85))
        return result

    except Exception:
        return None

# ── Routes ────────────────────────────────────────────────────────────────────

EXAMPLES = [
    {
        "label": "High Risk",
        "text": "Your bank account will be suspended today. Click here immediately to verify your login details: http://secure-bank-verify.xyz/login"
    },
    {
        "label": "Suspicious",
        "text": "Hi, this is your professor. Can you send me a gift card code before class starts? I'll explain later — it's urgent."
    },
    {
        "label": "Safe",
        "text": "Reminder: your library books are due next week. Visit the official campus library site for renewal details."
    }
]

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", examples=EXAMPLES)

@app.route("/analyze", methods=["POST"])
def analyze():
    user_input = request.form.get("user_input", "").strip()
    if not user_input:
        return redirect(url_for("index"))

    # Layer 1: rules
    risk_label, rule_flags, rule_confidence = rules_analysis(user_input)

    # Layer 2: AI (with rules as context)
    ai_result = ai_analysis(user_input, rule_flags)

    if ai_result:
        result = ai_result
        result["confidence"] = ai_result["confidence"]
    else:
        result = build_fallback_result(user_input, risk_label, rule_flags)
        result["confidence"] = rule_confidence

    # Log to database
    with get_db() as conn:
        conn.execute("""
            INSERT INTO analysis_logs
                (created_at, user_input, risk_label, reasons_json, actions_json, confidence, used_ai)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.utcnow().isoformat(),
            user_input,
            result["risk_label"],
            json.dumps(result["top_reasons"]),
            json.dumps(result["next_steps"]),
            result["confidence"],
            1 if result.get("used_ai") else 0
        ))
        conn.commit()

    # Store result in session for display
    session["result"] = result
    session["user_input"] = user_input
    return redirect(url_for("result"))

@app.route("/result")
def result():
    result = session.get("result")
    user_input = session.get("user_input", "")
    if not result:
        return redirect(url_for("index"))
    return render_template("result.html", result=result, user_input=user_input, examples=EXAMPLES)

@app.route("/metrics")
def metrics():
    with get_db() as conn:
        rows = conn.execute("""
            SELECT * FROM analysis_logs ORDER BY created_at DESC LIMIT 50
        """).fetchall()
        counts = conn.execute("""
            SELECT risk_label, COUNT(*) as cnt FROM analysis_logs GROUP BY risk_label
        """).fetchall()
        ai_count = conn.execute("SELECT COUNT(*) FROM analysis_logs WHERE used_ai = 1").fetchone()[0]
        total    = conn.execute("SELECT COUNT(*) FROM analysis_logs").fetchone()[0]

    logs = []
    for r in rows:
        logs.append({
            "id":         r["id"],
            "created_at": r["created_at"][:19].replace("T", " "),
            "risk_label": r["risk_label"],
            "confidence": r["confidence"],
            "used_ai":    r["used_ai"],
            "input_preview": r["user_input"][:80] + ("…" if len(r["user_input"]) > 80 else "")
        })

    label_counts = {r["risk_label"]: r["cnt"] for r in counts}

    return render_template("metrics.html",
        logs=logs,
        label_counts=label_counts,
        ai_count=ai_count,
        total=total
    )

# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=True)
